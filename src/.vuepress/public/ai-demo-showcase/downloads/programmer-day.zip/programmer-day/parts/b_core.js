'use strict';
/* ================= 基础：画布 / 调色板 / 工具 ================= */
const W = 320, H = 180;
const cv = document.getElementById('c');
const g = cv.getContext('2d', { alpha: false });
g.imageSmoothingEnabled = false;

// 统一 32 色调色板（ENDESGA 32）——全片所有像素只来自这里
const P = {
  ink:'#181425', night:'#262b44', navy:'#3a4466', slate:'#5a6988', gray:'#8b9bb4', light:'#c0cbdc', white:'#ffffff',
  deep:'#124e89', blue:'#0099db', cyan:'#2ce8f5', teal:'#193c3e', dgreen:'#265c42', green:'#3e8948', lime:'#63c74d',
  yellow:'#fee761', gold:'#feae34', orange:'#f77622', rust:'#be4a2f', tan:'#d77643', sand:'#ead4aa', skin:'#e4a672',
  brown:'#b86f50', dbrown:'#733e39', wine:'#3e2731', dred:'#a22633', red:'#e43b44', hot:'#ff0044', purple:'#68386c',
  pink:'#b55088', salmon:'#f6757a', peach:'#e8b796', clay:'#c28569'
};

const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, f) => a + (b - a) * f;
const ease = f => f * f * (3 - 2 * f);
const fr = (v) => v - Math.floor(v);
function hash(n) { n = Math.sin(n * 127.1 + 311.7) * 43758.5453; return n - Math.floor(n); }
function R(x, y, w, h, c) { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); }
function px(x, y, c) { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), 1, 1); }
// 1 像素的线（Bresenham）
function line(x0, y0, x1, y1, c) {
  x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
  g.fillStyle = c;
  let dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx + dy, n = 0;
  while (n++ < 400) { g.fillRect(x0, y0, 1, 1); if (x0 === x1 && y0 === y1) break; const e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; } }
}
function circ(cx, cy, r, c) { // 实心像素圆
  g.fillStyle = c;
  for (let y = -r; y <= r; y++) { const w = Math.floor(Math.sqrt(r * r - y * y + r * .8)); g.fillRect(Math.round(cx - w), Math.round(cy + y), w * 2 + 1, 1); }
}

// 有序抖动（4×4 Bayer）：用调色板颜色做"半透明"，保证不产生调色板外的颜色
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
const patCache = new Map();
function ditherPat(c, lvl) {
  const k = c + lvl; let p = patCache.get(k);
  if (!p) {
    const o = document.createElement('canvas'); o.width = o.height = 4;
    const x = o.getContext('2d'); x.fillStyle = c;
    for (let i = 0; i < 16; i++) if (BAYER[i] < lvl) x.fillRect(i & 3, i >> 2, 1, 1);
    p = g.createPattern(o, 'repeat'); patCache.set(k, p);
  }
  return p;
}
// lvl: 0..16（16 = 实心）
function dith(x, y, w, h, c, lvl) {
  lvl = Math.round(clamp(lvl, 0, 16)); if (lvl <= 0) return;
  if (lvl >= 16) return R(x, y, w, h, c);
  g.fillStyle = ditherPat(c, lvl); g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

/* ================= 3×5 像素字体（每行一个八进制数：4=左 2=中 1=右） ================= */
const FONT = {
  '0':'75557','1':'26227','2':'71747','3':'71317','4':'55711','5':'74717','6':'74757','7':'71122','8':'75757','9':'75717',
  A:'25755',B:'65656',C:'34443',D:'65556',E:'74647',F:'74644',G:'34553',H:'55755',I:'72227',J:'11152',K:'55655',L:'44447',M:'57755',
  N:'65555',O:'25552',P:'65644',Q:'25563',R:'65655',S:'34216',T:'72222',U:'55557',V:'55552',W:'55775',X:'55255',Y:'55222',Z:'71247',
  a:'03553',b:'46556',c:'03443',d:'13553',e:'02743',f:'12722',g:'35316',h:'46555',i:'20222',j:'10152',k:'45665',l:'62227',m:'06755',
  n:'06555',o:'02552',p:'06564',q:'03531',r:'05644',s:'03616',t:'27221',u:'05553',v:'05552',w:'05577',x:'05225',y:'05531',z:'07247',
  ' ':'00000','.':'00002',',':'00024',':':'02020',';':'02024','=':'07070','+':'02720','-':'00700','*':'05250','/':'11244',
  '(':'24442',')':'42224','{':'32623','}':'62326','[':'64446',']':'32223','<':'12421','>':'42124','!':'22202','?':'71202',
  "'":'22000','"':'55000','_':'00007','&':'25253','|':'22222','#':'57575','%':'51245','$':'36236','~':'03600','`':'42000','^':'25000','\\':'44211'
};
const GLYPH = {};
for (const k in FONT) GLYPH[k] = FONT[k].split('').map(Number);
function text(s, x, y, c) {
  g.fillStyle = c; x = Math.round(x); y = Math.round(y);
  for (let i = 0; i < s.length; i++) {
    const gl = GLYPH[s[i]];
    if (gl) for (let r = 0; r < 5; r++) { const b = gl[r]; if (!b) continue;
      if (b & 4) g.fillRect(x, y + r, 1, 1); if (b & 2) g.fillRect(x + 1, y + r, 1, 1); if (b & 1) g.fillRect(x + 2, y + r, 1, 1); }
    x += 4;
  }
}
const textW = s => s.length * 4 - 1;
function textC(s, cx, y, c) { text(s, cx - textW(s) / 2, y, c); }

/* ================= 时间轴 ================= */
// 每章：时长（秒）、游戏内时钟起止（分钟）
const CH = [
  { id:'alarm',   name:'闹钟',     dur:12, c0:420,  c1:447 },
  { id:'commute', name:'通勤',     dur:10, c0:510,  c1:548 },
  { id:'arrive',  name:'到工位',   dur:14, c0:570,  c1:615 },
  { id:'flow',    name:'心流',     dur:12, c0:630,  c1:715 },
  { id:'lunch',   name:'午饭',     dur:8,  c0:720,  c1:765 },
  { id:'alert',   name:'线上告警', dur:12, c0:840,  c1:920 },
  { id:'ai',      name:'AI 搭档',  dur:16, c0:930,  c1:1010 },
  { id:'deploy',  name:'部署',     dur:10, c0:1020, c1:1058 },
  { id:'pm',      name:'小地方',   dur:12, c0:1140, c1:1350 },
  { id:'night',   name:'深夜',     dur:14, c0:1380, c1:1439 }
];
let TOTAL = 0;
for (const c of CH) { c.t0 = TOTAL; TOTAL += c.dur; }
function chapterIndex(t) { for (let i = CH.length - 1; i >= 0; i--) if (t >= CH[i].t0) return i; return 0; }
function clockAt(t) {
  const c = CH[chapterIndex(t)], lt = t - c.t0;
  if (c.clock) return c.clock(lt);
  return lerp(c.c0, c.c1, clamp(lt / c.dur, 0, 1));
}
const fmtClock = m => { m = Math.floor(m) % 1440; return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };

// 状态栏数值：全部是时间的纯函数 → 拖动时间轴永远不会错乱
function keyInterp(keys, t) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) if (t < keys[i][0]) {
    const a = keys[i - 1], b = keys[i]; return lerp(a[1], b[1], ease((t - a[0]) / (b[0] - a[0])));
  }
  return keys[keys.length - 1][1];
}
const stepCount = (arr, t) => { let n = 0; for (const x of arr) if (t >= x) n++; return n; };
const ENERGY = [[0,12],[9,22],[12,30],[20,34],[26,72],[36,82],[47,50],[51,72],[57,22],[60.5,92],[68,58],[80,40],[86,78],[95,48],[98,18],[106,10],[116,8],[117.5,96],[120,12]];
const COFFEE_T = [26, 40.5, 67, 73];
const COMMIT_T = [39.2, 41.6, 44, 46.3, 81.5, 86.2, 104];
const BUG_K = [[60.2,1],[62,3],[64,5],[79.4,1],[81.5,0],[104.5,1]];
function bugsAt(t) { let v = 0; for (const k of BUG_K) if (t >= k[0]) v = k[1]; return v; }

/* ================= 天气（每天随机，但对同一天是确定的） ================= */
let day = 0;
function rainAt(min) {
  let a, b;
  if (day === 0) { a = 835; b = 1065; }            // 第一天：午后必下一场雨
  else { const h = hash(day * 7.3); if (h < .35) return 0; a = 450 + hash(day * 3.1) * 700; b = a + 90 + hash(day * 9.7) * 260; }
  if (min < a || min > b) return 0;
  return clamp(Math.min(min - a, b - min) / 25, 0, 1); // 渐入渐出
}
