
/* ================= 环境：天空 / 窗户 / 家具 / 道具 ================= */
// 天空关键帧 [分钟, 上, 下]；两帧之间用抖动过渡，颜色永远落在调色板里
const SKY = [
  [0, P.ink, P.night], [360, P.ink, P.night], [420, P.night, P.purple], [440, P.navy, P.salmon], [470, P.deep, P.peach],
  [540, P.blue, P.cyan], [960, P.blue, P.cyan], [1030, P.deep, P.gold], [1080, P.purple, P.orange], [1120, P.night, P.pink],
  [1170, P.ink, P.purple], [1230, P.ink, P.night], [1440, P.ink, P.night]
];
function skyAt(min) {
  for (let i = 1; i < SKY.length; i++) if (min < SKY[i][0]) { const a = SKY[i - 1], b = SKY[i]; return [a, b, (min - a[0]) / (b[0] - a[0])]; }
  return [SKY[SKY.length - 1], SKY[SKY.length - 1], 0];
}
function drawSky(x, y, w, h, min) {
  const [a, b, f] = skyAt(min), lv = Math.round(f * 16);
  const half = Math.ceil(h * .55);
  R(x, y, w, h, a[1]); dith(x, y + half, w, h - half, a[2], 8); R(x, y + h - Math.ceil(h * .25), w, Math.ceil(h * .25), a[2]);
  R(x, y, w, half - 2, a[1]);
  if (lv) { // 叠上下一帧
    dith(x, y, w, half, b[1], lv); dith(x, y + half, w, h - half, b[2], lv);
  }
  const night = min < 400 || min > 1150;
  if (night) for (let i = 0; i < w * h / 260; i++) { const sx = x + hash(i * 3.7) * w, sy = y + hash(i * 5.1) * h * .6; if (hash(i * 9 + Math.floor(min / 7)) > .2) px(sx, sy, hash(i * 2.2) > .7 ? P.yellow : P.light); }
  return night;
}
// 雨：滴落的斜线 + 天色变灰
function drawRain(x, y, w, h, amt, t, c) {
  if (amt <= 0) return;
  dith(x, y, w, h, P.slate, Math.round(amt * 7));
  const n = Math.round(w * h / 60 * amt);
  for (let i = 0; i < n; i++) {
    const sp = 90 + hash(i * 1.3) * 40;
    const rx = x + fr(hash(i * 7.1) + t * .05) * w, ry = y + fr(hash(i * 3.3) + t * sp / h) * h;
    if (ry + 3 < y + h) { px(rx, ry, c || P.light); px(rx - 1, ry + 2, c || P.gray); }
  }
}
// 城市剪影（可平移做视差）
function skyline(x, y, w, h, off, seed, col, lit, min) {
  let cx = -(off % 400);
  let i = Math.floor(off / 400) * 40;
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  while (cx < w + 40) {
    const bw = 10 + Math.floor(hash(seed + i * 1.7) * 18), bh = 10 + Math.floor(hash(seed + i * 2.9) * (h - 12));
    const bx = x + cx, by = y + h - bh;
    R(bx, by, bw, bh, col);
    if (hash(seed + i * 4.4) > .7) R(bx + (bw >> 1), by - 4, 1, 4, col);
    if (lit) for (let wy = by + 3; wy < y + h - 2; wy += 4) for (let wx = bx + 2; wx < bx + bw - 2; wx += 3) {
      const hh = hash(wx * 1.31 + wy * 7.7 + seed + i);
      const on = hh > (min > 1400 ? .8 : .55) && hash(hh * 91 + Math.floor((min || 0) / 3)) > .15;
      if (on) px(wx, wy, hh > .93 ? P.cyan : P.yellow);
    }
    cx += bw + 1 + Math.floor(hash(seed + i * 5.3) * 4); i++;
  }
  g.restore();
}
function drawWindow(x, y, w, h, min, t, o = {}) {
  R(x - 2, y - 2, w + 4, h + 4, o.frame || P.light);
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  const night = drawSky(x, y, w, h, min);
  if (!night && min > 460) { // 云
    for (let i = 0; i < 3; i++) { const cx = x + fr(hash(i * 4.1) + t * .006 * (i + 1)) * (w + 30) - 15, cy = y + 4 + i * 6;
      R(cx, cy, 12, 3, P.white); R(cx + 3, cy - 2, 6, 2, P.white); }
  }
  if (min > 330 && min < 450 && !o.noSun) circ(x + w * .7, y + h - (min - 330) / 120 * h * .9, 3, P.gold);
  if (night && o.moon !== false) { circ(x + w * .75, y + 7, 3, P.sand); circ(x + w * .75 + 2, y + 6, 2, skyAt(min)[0][1]); }
  skyline(x, y + h - (o.sky || 14), w, o.sky || 14, o.off || 0, o.seed || 3, night ? P.ink : P.slate, night || min > 1100, min);
  drawRain(x, y, w, h, rainAt(min), t);
  g.restore();
  R(x + (w >> 1) - 1, y, 2, h, o.frame || P.light); R(x, y + (h >> 1), w, 1, o.frame || P.light);
  if (rainAt(min) > .3) for (let i = 0; i < 4; i++) { const dy = fr(hash(i * 8) + t * .15) * h; px(x + 3 + hash(i * 2) * (w - 6), y + dy, P.cyan); }
}
// 室内色温：清晨暖粉、午后金黄、傍晚紫、深夜暗
function ambient(min, x = 0, y = 10, w = W, h = H - 10) {
  if (min >= 1080 && min < 1200) dith(x, y, w, h, P.purple, Math.round(clamp((min - 1080) / 80, 0, 1) * 3));
  else if (min >= 1200) dith(x, y, w, h, P.ink, 6);
}
// 窗户投到地上的光斑：清晨粉、白天亮黄、午后金、傍晚橙
function sunPatch(x, w, min) {
  if (min < 430 || min > 1130) return;
  const c = min < 480 ? P.peach : min < 900 ? P.yellow : min < 1040 ? P.gold : P.orange;
  const sk = min < 720 ? -1 : 1, lv = rainAt(min) > .3 ? 2 : 4;
  for (let i = 0; i < 8; i++) dith(x + sk * i * 3, FLOOR + i * 2, w, 2, c, lv);
}

/* ---------- 家具 ---------- */
function desk(x, y, w) { R(x, y, w, 3, P.brown); R(x, y + 3, w, 1, P.dbrown); R(x + 2, y + 4, 2, 60, P.dbrown); R(x + w - 4, y + 4, 2, 60, P.dbrown); }
function chair(x, y, c = P.navy) { R(x - 4, y - 7, 9, 2, c); R(x - 5, y - 17, 2, 11, c); R(x, y - 5, 1, 4, P.ink); R(x - 3, y - 1, 7, 1, P.ink); }
function mug(x, y, level, t, steam, c = P.white) {
  R(x, y, 5, 5, c); R(x + 5, y + 1, 1, 3, c); R(x + 1, y + 1, 3, 1, level > 0 ? P.dbrown : P.light);
  if (level > .66) R(x + 1, y + 1, 3, 1, P.wine);
  if (steam) for (let i = 0; i < 3; i++) { const p = fr(t * .7 + i / 3); if (p < .9) px(x + 1 + i + Math.round(Math.sin(p * 9 + i) * 1), y - 1 - p * 8, p < .5 ? P.light : P.gray); }
}
function plant(x, y) { R(x, y - 5, 6, 5, P.rust); R(x + 1, y - 10, 1, 5, P.green); R(x + 3, y - 12, 1, 7, P.lime); R(x + 4, y - 9, 2, 2, P.green); R(x - 1, y - 9, 2, 2, P.lime); }
// 显示器：内容由回调在 (sx,sy,sw,sh) 里画
function monitor(x, y, w, h, drawScreen) {
  R(x - 2, y - 2, w + 4, h + 4, P.ink); R(x - 1, y - 1, w + 2, h + 2, P.navy);
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  if (drawScreen) drawScreen(x, y, w, h); else R(x, y, w, h, P.ink);
  g.restore();
  R(x + (w >> 1) - 2, y + h + 2, 4, 3, P.navy); R(x + (w >> 1) - 5, y + h + 5, 10, 1, P.navy);
}
function keyboard(x, y, t, active) {
  R(x, y, 12, 2, P.gray); R(x, y + 2, 12, 1, P.slate);
  if (active) px(x + 1 + Math.floor(hash(Math.floor(t * 12)) * 10), y, P.white);
}
function coffeeMachine(x, y, t, brewing) {
  R(x, y, 14, 20, P.navy); R(x, y, 14, 3, P.slate); R(x + 2, y + 5, 10, 5, P.ink);
  px(x + 3, y + 6, brewing ? P.lime : P.red); text('Cf', x + 5, y + 5, P.cyan);
  R(x + 5, y + 11, 4, 2, P.slate);
  if (brewing) { const p = Math.floor(t * 12) % 3; px(x + 7, y + 13 + p, P.dbrown); px(x + 7, y + 14, P.dbrown); }
  R(x, y + 18, 14, 2, P.slate);
}

/* ---------- 代码屏（彩蛋：真实代码） ---------- */
const CODE = [
  ['// user permission check', 'c'],
  ['function canDeploy(user) {', 'k'],
  ['  if (user.role = "admin") {', 'b'],
  ['    return true;', 'k'],
  ['  }', 'n'],
  ['  return user.tests >= 0;', 'k'],
  ['}', 'n'],
  ['', 'n'],
  ['while (!done) {', 'k'],
  ['  coffee++;', 'n'],
  ['  code();', 'n'],
  ['}', 'n'],
  ['', 'n'],
  ['for (let i = 1; i <= 15; i++)', 'k'],
  ['  console.log(i % 15 ? i % 5', 'n'],
  ['   ? i % 3 ? i : "Fizz"', 's'],
  ['   : "Buzz" : "FizzBuzz");', 's'],
  ['', 'n'],
  ['// TODO: refactor (2019)', 'c'],
  ['const sleep = () => null;', 'k'],
  ['git commit -m "fix typo"', 's'],
  ['', 'n']
];
const CODE_COL = { c: P.slate, k: P.cyan, n: P.light, s: P.gold, b: P.light };
// 画到屏幕上：scroll 为已滚动行数（可带小数），typed 为当前行已打出的字符数
function codeScreen(x, y, w, h, scroll, typedChars, t, o = {}) {
  R(x, y, w, h, o.bg || P.ink);
  const lh = 7, first = Math.floor(scroll), dy = -Math.round((scroll - first) * lh);
  const rows = Math.ceil(h / lh) + 1;
  let cursor = null;
  for (let r = 0; r < rows; r++) {
    const li = first + r; if (li < 0) continue;
    const L = CODE[li % CODE.length];
    const ly = y + 2 + r * lh + dy;
    text(String((li % 99) + 1).padStart(2, ' '), x + 1, ly, P.navy);
    let s = L[0];
    const isLast = r === rows - 2;
    if (typedChars != null && isLast) { s = s.slice(0, typedChars); cursor = [x + 11 + textW(s) + 1, ly]; }
    if (typedChars != null && r > rows - 2) continue;
    let col = CODE_COL[L[1]];
    if (L[1] === 'b' && o.bugHi) { R(x + 9, ly - 1, w - 9, 7, o.bugHi); col = P.white; }
    text(s, x + 11, ly, col);
  }
  if (cursor && Math.floor(t * 2.5) % 2 === 0) R(cursor[0], cursor[1], 1, 5, P.white);
}
