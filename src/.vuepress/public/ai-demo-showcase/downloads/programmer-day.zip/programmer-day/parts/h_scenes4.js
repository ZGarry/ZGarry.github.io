
/* ================= 9. 19:00 "就改一个小地方" ================= */
function lamp(x, on) {
  R(x - 8, 10, 16, 2, P.gray); R(x - 6, 12, 12, 1, on ? P.yellow : P.slate);
  if (on) { dith(x - 9, 13, 18, 5, P.yellow, 3); dith(x - 16, FLOOR, 32, 5, P.yellow, 4); }
}
Object.assign(CH[8], {
  mood: 'pm', moodAt: lt => lt < 5.5 ? 'pm' : 'overtime',
  clock: lt => lt < 5.5 ? 1140 + lt : lt < 11 ? lerp(1145.5, 1350, ease((lt - 5.5) / 5.5)) : 1350 + (lt - 11) * 2,
  sfx: [[3.2, 'uhoh'], [5.5, 'whoosh'], [9.6, 'facepalm'], [10, 'commit']],
  draw(lt, t) {
    const min = clockAt(t);
    officeBg(min, t);
    const work = lt >= 5.5 && lt < 10.4;
    deskSet(t, { typing: work, screen: (x, y, w, h) => {
      if (!work) { R(x, y, w, h, P.night); text('bye', x + 12, y + 8, P.gray); return; }
      R(x, y, w, h, P.ink); const k = Math.floor(clamp((lt - 5.5) / 4.5, 0, 1) * 1024);
      text('+' + k, x + 2, y + 2, P.lime); text('-' + Math.floor(k * .75), x + 2, y + 9, P.red);
      text(Math.floor(lt * 6) % 2 ? '>>' : ' >', x + 24, y + 15, P.gold);
    }});
    ambient(min);
    const offAt = [6.4, 7.4, 99, 8.6];
    [40, 120, 200, 280].forEach((x, i) => lamp(x, lt < offAt[i]));
    let hx = 140, pose = 'sit', dir = 1, eyes = 'open', sweat = false;
    if (lt < .6) pose = 'stand';
    else if (lt < 3.1) { pose = 'walk'; hx = lerp(140, 226, (lt - .6) / 2.5); }
    else if (lt < 5.5) { pose = lt < 4.4 ? 'stand' : 'scratch'; hx = 226; eyes = 'wide'; sweat = true; }
    else if (lt < 9.6) pose = 'type';
    else if (lt < 10.4) pose = 'facepalmSit';
    else { pose = 'walk'; hx = lerp(140, 330, (lt - 10.4) / 1.6); eyes = 'tired'; }
    guy(hx, FLOOR, { pose, dir, t: lt, eyes, sweat, bag: pose === 'sit' || pose === 'type' || pose === 'facepalmSit' ? null : P.green, glow: work ? P.cyan : null });
    if (work) R(118, 146, 10, 4, P.green);
    if (lt > 2.4 && lt < 5.6) {
      const px_ = lerp(334, 262, clamp((lt - 2.4) / .8, 0, 1));
      mate('pm', px_, FLOOR, { pose: lt < 3.2 ? 'walk' : 'point', dir: -1, t: lt, talk: lt > 3.2 && lt < 4.6, mouth: 'smile' });
    }
    if (lt > 5.8 && lt < 7.2) mate('zhao', lerp(60, -12, (lt - 5.8) / 1.4), FLOOR, { pose: 'walk', dir: -1, t: lt, bag: P.purple });
    if (lt > 6.8 && lt < 8.4) mate('lin', lerp(270, 334, (lt - 6.8) / 1.6), FLOOR, { pose: 'walk', dir: 1, t: lt, bag: P.pink });
    if (work) text('>> x40', 236, 14, Math.floor(lt * 3) % 2 ? P.gold : P.orange);
  },
  bub(lt) {
    return [say(lt, 3.2, 5.2, 262, 124, '就改一个小地方。', 'shout'), say(lt, 4.2, 5.5, 226, 104, '……', 'think'),
      say(lt, 6.2, 7.4, 60, 124, '走了啊～', ''), say(lt, 9.6, 10.6, 140, 104, '小……地……方……', 'think')];
  },
  hits() { return [{ x: 194, y: 108, w: 12, h: 14, id: 'mug' }]; }
});

/* ================= 10. 23:00 深夜 → 第二天 ================= */
Object.assign(CH[9], {
  mood: 'night', moodAt: lt => lt < 10.4 ? 'night' : 'idea',
  sfx: [[10.4, 'idea'], [12.4, 'alarmSoft']],
  draw(lt, t) {
    const min = clockAt(t);
    if (lt < 5) {
      drawSky(0, 10, W, 170, min);
      circ(262, 38, 9, P.sand); circ(266, 35, 8, P.ink); px(258, 36, P.peach); px(256, 42, P.peach);
      const pan = lt * 8;
      skyline(0, 90, W, 78, pan * .4 + 100, 41, P.night, true, min);
      skyline(0, 118, W, 50, pan + 300, 77, P.ink, true, min);
      // 公司大楼：最后一盏灯在 2.5 秒熄灭
      const bx = 150 - pan;
      R(bx, 70, 36, 98, P.ink); R(bx + 16, 62, 2, 8, P.ink); px(bx + 16, 60, Math.floor(lt * 2) % 2 ? P.hot : P.dred);
      for (let wy = 0; wy < 8; wy++) for (let wx = 0; wx < 5; wx++) {
        const lit = wy === 3 && wx === 2 ? lt < 2.5 : hash(wx * 7 + wy * 13) > .72;
        R(bx + 4 + wx * 6, 76 + wy * 10, 3, 4, lit ? (wy === 3 && wx === 2 ? P.cyan : P.yellow) : P.night);
      }
      R(0, 168, W, 12, P.night); R(0, 168, W, 1, P.navy);
      for (let lx = 20; lx < W; lx += 70) { R(lx, 150, 1, 18, P.slate); R(lx - 2, 149, 5, 1, P.slate); dith(lx - 8, 150, 17, 18, P.yellow, 2); px(lx, 150, P.yellow); }
      if (lt > 2.8) guy(lerp(120, 200, (lt - 2.8) / 2.2), 178, { pose: 'walk', t: lt, bag: P.green, eyes: 'tired' });
      drawRain(0, 10, W, 170, rainAt(min), t);
      return;
    }
    const L = lt - 5;
    room(min, P.night, P.ink);
    drawWindow(36, 40, 74, 58, min, t, { seed: 11 });
    R(32, 99, 82, 3, P.light);
    bedroomDecor();
    R(144, 104, 5, 46, P.dbrown); R(148, 128, 122, 6, P.dbrown); R(150, 134, 3, 16, P.dbrown); R(265, 134, 3, 16, P.dbrown); R(148, 123, 122, 5, P.light);
    R(116, 124, 26, 26, P.brown); R(121, 113, 16, 11, P.red); R(123, 115, 12, 7, P.ink); text(fmtClock(min).slice(1), 124, 116, P.lime);
    R(128, 122, 6, 2, P.ink); R(130, 118, 2, 4, P.ink); px(131, 117, P.cyan);   // 充电中的手机
    dith(40, 150, 90, 30, P.deep, 5);   // 月光
    const up = L > 7.4;
    if (!up) {
      R(150, 118, 16, 6, P.white);
      R(154, 112, 7, 7, P.skin); R(153, 111, 5, 8, P.ink); R(154, 110, 6, 2, P.ink);
      if (L > 5.4) { R(158, 115, 2, 2, P.white); px(159, 116, P.ink); } else R(158, 116, 3, 1, P.dbrown);
      R(160, 117, 100, 8, P.red); R(160, 117, 100, 1, P.salmon); R(180, 119, 1, 5, P.dred); R(250, 115, 12, 3, P.red);
      if (L < 5.4) Zs(166, 108, L);
    } else {
      R(186, 118, 76, 7, P.red);
      guy(172, 130, { pose: 'think', t: L, eyes: 'wide' });
    }
    cat(220, 117, t, { sleep: true, meow: since('meow') < 1.2 ? 1 : 0 });
    ambient(min);
    if (L > 5.8) {   // 灵光一闪的灯泡
      const bx = up ? 172 : 157, by = up ? 94 : 96, on = Math.floor(L * 6) % 3 !== 0 || L > 6.6;
      circ(bx, by, 3, on ? P.yellow : P.gold); R(bx - 1, by + 3, 3, 2, P.gray);
      if (on) for (const [dx, dy] of [[-6, 0], [6, 0], [0, -6], [-4, -4], [4, -4]]) px(bx + dx, by + dy, P.yellow);
    }
  },
  bub(lt) {
    const L = lt - 5;
    return [say(lt, .4, 2.4, 168, 60, '最后一盏灯', 'think'), say(L, 6.2, 8.6, 160, 88, '等等……这里可以用 reduce！', 'think'),
      say(L, 8.6, 9, 172, 88, '！', 'shout')];
  },
  hits(lt) { return lt >= 5 ? [{ x: 216, y: 104, w: 20, h: 16, id: 'cat' }] : []; }
});
