
/* ================= 主循环 / 状态栏 / 转场 / 交互 ================= */
CH[2].cuts = [8.6]; CH[6].cuts = [12]; CH[7].cuts = [6.9]; CH[8].cuts = [5.5]; CH[9].cuts = [5];
let t = 0, playing = true, speed = 1, last = performance.now(), dragging = false;
const $ = id => document.getElementById(id);
const stage = $('stage'), ov = $('ov'), tl = $('tl');

function typingAt(t) {
  const i = chapterIndex(t), lt = t - CH[i].t0;
  return i === 3 || (i === 5 && lt > 3.8) || (i === 6 && (lt < 2.2 || lt > 13.5)) || (i === 8 && lt > 5.5 && lt < 9.6);
}
function fireEvents(a, b) {   // 触发 [a,b) 之间的音效
  if (b <= a) return;
  for (const c of CH) for (const [lt, n] of c.sfx) { const e = c.t0 + lt; if (e >= a && e < b) AU.play(n); }
  for (const e of COMMIT_T) if (e >= a && e < b) AU.play('commit');
}

/* ---------- 状态栏 ---------- */
function statusBar() {
  const min = clockAt(t);
  R(0, 0, W, 10, P.ink); R(0, 10, W, 1, P.navy);
  if (min >= 400 && min < 1140) { circ(5, 5, 2, P.gold); } else { circ(5, 5, 2, P.sand); R(6, 3, 2, 3, P.ink); }
  text(fmtClock(min), 11, 3, P.white);
  // 精力
  const en = keyInterp(ENERGY, t);
  px(36, 2, P.yellow); R(35, 3, 2, 2, P.yellow); R(34, 5, 3, 1, P.yellow); R(35, 6, 2, 1, P.yellow); px(35, 7, P.yellow);
  R(40, 3, 32, 5, P.navy); R(41, 4, 30, 3, P.ink);
  const ec = en > 60 ? P.lime : en > 30 ? P.gold : P.red;
  if (!(en < 20 && Math.floor(RT * 3) % 2)) R(41, 4, Math.round(30 * en / 100), 3, ec);
  // 咖啡
  const cups = stepCount(COFFEE_T, t) + FX.extra;
  R(80, 3, 4, 5, P.white); px(84, 4, P.white); px(84, 5, P.white); R(81, 4, 2, 1, P.dbrown);
  text('x' + cups, 87, 3, P.sand);
  // 提交
  const cm = stepCount(COMMIT_T, t);
  R(106, 5, 7, 1, P.green); circ(109, 5, 1, P.lime);
  text(String(cm), 116, 3, P.lime);
  // bug
  const bg = bugsAt(t), blink = bg > 0 && Math.floor(RT * 2) % 2;
  R(134, 3, 4, 5, blink ? P.hot : P.red); px(133, 4, P.ink); px(138, 4, P.ink); px(133, 6, P.ink); px(138, 6, P.ink);
  px(132, 4, P.gray); px(139, 4, P.gray); px(132, 6, P.gray); px(139, 6, P.gray); px(135, 2, P.gray); px(136, 2, P.gray);
  text(String(bg), 142, 3, bg ? P.salmon : P.gray);
  // 右侧：天气 + 第几天
  if (rainAt(min) > 0) { for (let i = 0; i < 3; i++) R(262 + i * 4, 3 + (i % 2), 1, 3, P.cyan); }
  const d = 'DAY ' + (day + 1); text(d, W - textW(d) - 3, 3, P.gray);
}

/* ---------- 画面 ---------- */
function render() {
  const i = chapterIndex(t), c = CH[i], lt = t - c.t0;
  g.setTransform(1, 0, 0, 1, 0, 0);
  c.draw(lt, t);
  g.setTransform(1, 0, 0, 1, 0, 0);
  // 章节转场：像素抖动淡入淡出；章内切镜头更短
  const d = Math.min(lt, c.dur - lt);
  if (d < .5) dith(0, 10, W, H - 10, P.ink, (1 - d / .5) * 16);
  for (const k of c.cuts || []) { const e = Math.abs(lt - k); if (e < .25) dith(0, 10, W, H - 10, P.ink, (1 - e / .25) * 16); }
  if (!playing) { R(W - 12, 14, 3, 9, P.white); R(W - 7, 14, 3, 9, P.white); }
  statusBar();
}

/* ---------- 台词气泡（DOM 覆盖层，文字清晰且不受最小字号影响） ---------- */
let lastKey = '';
function updateBubbles() {
  const i = chapterIndex(t), c = CH[i], lt = t - c.t0;
  const list = c.bub(lt).filter(Boolean);
  if (FX.pop && RT < FX.pop.until) list.push(FX.pop);
  const card = lt < 2.6 ? fmtClock(clockAt(c.t0 + .01)) + '|' + c.name : '';
  const key = card + '#' + list.map(b => b.s + b.x + b.y + b.cls).join('|');
  if (key === lastKey) return;
  lastKey = key;
  let h = card ? `<div class="card">${card.split('|')[0]}<small>${String(i + 1).padStart(2, '0')} · ${card.split('|')[1]}</small></div>` : '';
  for (const b of list) h += `<div class="bb ${b.cls || ''}" style="left:${b.x / W * 100}%;top:${b.y / H * 100}%">${b.s}</div>`;
  ov.innerHTML = h;
  // 贴边的气泡往里收，保证文字不溢出画面
  const ow = ov.clientWidth;
  for (const el of ov.querySelectorAll('.bb')) {
    const bw = el.offsetWidth, cx = parseFloat(el.style.left) / 100 * ow;
    const nx = clamp(cx, bw / 2 + 3, ow - bw / 2 - 3);
    if (nx !== cx) el.style.left = nx + 'px';
  }
}

/* ---------- 尺寸：整数倍放大 ---------- */
function resize() {
  const sw = stage.clientWidth, sh = stage.clientHeight, dpr = window.devicePixelRatio || 1;
  const k = Math.floor(Math.min(sw * dpr / W, sh * dpr / H));
  let cw = k >= 1 ? k * W / dpr : Math.min(sw, sh * W / H);
  const ch = cw * H / W;
  cv.style.width = cw + 'px'; cv.style.height = ch + 'px';
  Object.assign(ov.style, { left: (sw - cw) / 2 + 'px', top: (sh - ch) / 2 + 'px', width: cw + 'px', height: ch + 'px' });
  ov.style.setProperty('--fs', Math.max(11, Math.round(cw / 44)) + 'px');
  lastKey = '';
}
window.addEventListener('resize', resize);

/* ---------- 控件 ---------- */
const chapsEl = $('chaps'), marks = $('tlmarks');
CH.forEach((c, i) => {
  const b = document.createElement('button');
  b.innerHTML = `<b>${fmtClock(c.c0)}</b>${c.name}`;
  b.onclick = () => { t = c.t0 + .5; lastKey = ""; };
  chapsEl.appendChild(b); c.btn = b;
  if (i) { const m = document.createElement('i'); m.style.left = c.t0 / TOTAL * 100 + '%'; marks.appendChild(m); }
});
function setPlaying(p) { playing = p; $('play').textContent = p ? '❚❚' : '▶'; }
function setSpeed(s) { speed = s; for (const b of $('speed').children) b.classList.toggle('on', +b.dataset.s === s); }
function enableSound() { AU.init(); if (AU.ctx) { AU.setMuted(false); $('mute').textContent = '♪ 开'; $('mute').classList.add('on'); } $('hint').style.display = 'none'; }
function toggleMute() { if (!AU.ctx || AU.muted) enableSound(); else { AU.setMuted(true); $('mute').textContent = '♪ 关'; $('mute').classList.remove('on'); } }
$('play').onclick = () => setPlaying(!playing);
for (const b of $('speed').children) b.onclick = () => setSpeed(+b.dataset.s);
$('mute').onclick = toggleMute;
function seekFrom(e) { const r = tl.getBoundingClientRect(); t = clamp((e.clientX - r.left) / r.width, 0, .99999) * TOTAL; lastKey = ''; }
tl.addEventListener('pointerdown', e => { dragging = true; tl.setPointerCapture(e.pointerId); seekFrom(e); });
tl.addEventListener('pointermove', e => { if (dragging) seekFrom(e); });
const endDrag = () => { dragging = false; };
tl.addEventListener('pointerup', endDrag); tl.addEventListener('pointercancel', endDrag);
window.addEventListener('keydown', e => {
  if (e.code === 'Space') { e.preventDefault(); setPlaying(!playing); }
  else if (e.key >= '1' && e.key <= '3') setSpeed(+e.key);
  else if (e.key === 'm' || e.key === 'M') toggleMute();
  else if (e.key === 'ArrowRight') { t = Math.min(TOTAL - .001, t + 5); lastKey = ''; }
  else if (e.key === 'ArrowLeft') { t = Math.max(0, t - 5); lastKey = ''; }
});
// 点击画面：第一次开启声音；点中彩蛋触发互动
cv.addEventListener('pointerdown', e => {
  if (!AU.started) { AU.started = true; enableSound(); }
  const r = cv.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * W, y = (e.clientY - r.top) / r.height * H;
  const c = CH[chapterIndex(t)], lt = t - c.t0;
  const hit = c.hits(lt).find(h => x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h);
  if (!hit) return;
  const pop = s => { FX.pop = { x: hit.x + hit.w / 2, y: hit.y - 2, s, cls: '', until: RT + 1.3 }; lastKey = ''; };
  if (hit.id === 'cat') { FX.meow = RT; AU.play('meow'); pop(['喵～', '喵？', '喵喵！'][Math.floor(Math.random() * 3)]); }
  else if (hit.id === 'clock') { FX.snooze = RT; AU.play('snooze'); pop('再贪睡一次？'); }
  else if (hit.id === 'coffee' || hit.id === 'mug') { FX.refill = RT; FX.extra++; AU.play('coffee'); pop('续杯 +1'); }
  else if (hit.id === 'bot') { FX.bot = RT; AU.play('bot'); }
});

/* ---------- 主循环：时间推进与帧率无关 ---------- */
let lastChap = -1, lastTxt = '';
function frame(now) {
  const dt = Math.min(.1, Math.max(0, (now - last) / 1000)); last = now; RT += dt;
  if (playing && !dragging) {
    const nt = t + dt * speed;
    if (nt >= TOTAL) { fireEvents(t, TOTAL); t = nt - TOTAL; day++; fireEvents(0, t); lastKey = ''; }
    else { fireEvents(t, nt); t = nt; }
  }
  render();
  updateBubbles();
  const i = chapterIndex(t), c = CH[i];
  AU.tick(c.moodAt ? c.moodAt(t - c.t0) : c.mood, playing && !dragging ? speed : 0, typingAt(t) && playing && !dragging);
  const f = t / TOTAL * 100 + '%';
  $('tlfill').style.width = f; $('tlknob').style.left = f;
  const txt = fmtClock(clockAt(t)); if (txt !== lastTxt) { $('time').textContent = txt; lastTxt = txt; }
  if (i !== lastChap) {
    if (lastChap >= 0) CH[lastChap].btn.classList.remove('on');
    c.btn.classList.add('on'); lastChap = i;
    chapsEl.scrollTo({ left: c.btn.offsetLeft - chapsEl.clientWidth / 2 + c.btn.offsetWidth / 2, behavior: 'smooth' });
  }
  requestAnimationFrame(frame);
}
resize();
requestAnimationFrame(frame);
