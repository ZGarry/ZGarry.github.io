
/* ================= 6. 14:00 犯困 → 线上告警 ================= */
function errGraph(x, y, w, h, lt, a) {
  R(x, y, w, h, P.ink);
  for (let i = 0; i < w; i += 2) {
    const v = lt < a ? 2 + hash(i) * 3 : 2 + hash(i + Math.floor(lt * 4)) * 3 + (i > w * .55 ? (i - w * .55) / (w * .45) * (h - 8) : 0);
    R(x + i, y + h - v, 1, v, i > w * .55 && lt >= a ? P.red : P.lime);
  }
}
Object.assign(CH[5], {
  mood: 'alert', moodAt: lt => lt < 3.8 ? 'sleepy' : 'alert',
  sfx: [[3.8, 'siren'], [5.2, 'siren'], [6.6, 'siren']],
  draw(lt, t) {
    const min = clockAt(t), A = 3.8, al = lt >= A;
    officeBg(min, t);
    deskSet(t, { typing: al, screen: (x, y, w, h) => {
      if (!al) { codeScreen(x, y, w, h, 2, null, t, { bg: P.night }); dith(x, y, w, h, P.ink, 8); return; }
      R(x, y, w, h, Math.floor(lt * 4) % 2 ? P.red : P.dred); text('P0', x + 2, y + 2, P.white); text('5XX', x + 15, y + 2, P.yellow);
      errGraph(x + 2, y + 9, w - 4, h - 11, lt, A);
    }});
    let pose = 'sleepy', eyes = 'open';
    if (al) { pose = lt > 7 && lt < 9.4 ? 'scratchSit' : 'type'; eyes = 'wide'; }
    guy(140, FLOOR, { pose, t: lt, eyes, glow: al ? P.red : null, sweat: al && lt > 5 });
    if (!al) Zs(146, 118, lt);
    if (al && lt < 5) { R(141, 108, 2, 5, P.yellow); R(141, 114, 2, 1, P.yellow); }
    // 同事围过来
    if (lt > 4.6) mate('wang', lerp(330, 196, clamp((lt - 4.6) / 1.2, 0, 1)), FLOOR, { pose: lt < 5.8 ? 'walk' : 'stand', dir: -1, t: lt, talk: lt > 5.9 && lt < 7 });
    if (lt > 5.1) mate('zhao', lerp(340, 226, clamp((lt - 5.1) / 1.2, 0, 1)), FLOOR, { pose: lt < 6.3 ? 'walk' : 'scratch', dir: -1, t: lt, talk: lt > 7 && lt < 8.2 });
    if (lt > 5.4) mate('lin', lerp(-10, 100, clamp((lt - 5.4) / 1.2, 0, 1)), FLOOR, { pose: lt < 6.6 ? 'walk' : 'stand', dir: 1, t: lt, talk: lt > 8.2 && lt < 9.4 });
    ambient(min);
    if (al) dith(0, 10, W, H - 10, P.red, Math.floor(lt * 4) % 2 ? 3 : 1);   // 告警红光
  },
  bub(lt) {
    return [say(lt, 3.9, 5.6, 140, 104, 'P0 告警！！', 'shout'), say(lt, 5.9, 7, 196, 124, '谁动了线上？', ''),
      say(lt, 7, 8.2, 226, 124, '不……不是我', ''), say(lt, 8.2, 9.4, 100, 124, '要不先回滚？', ''),
      say(lt, 9.5, 11.6, 140, 104, '先看日志……', '')];
  },
  hits() { return [{ x: 194, y: 108, w: 12, h: 14, id: 'mug' }]; }
});
COFFEE_T[1] = 57.5;

/* ================= 7. 15:30 和 AI 搭档排查 ================= */
const TESTS = [['unit', 2.4, 1], ['api', 3.2, 1], ['e2e', 4.2, 1], ['auth', 4.8, 0]];
Object.assign(CH[6], {
  mood: 'ai',
  sfx: [[.4, 'type'], [2.2, 'bot'], [3.6, 'split'], [7.4, 'ok'], [8.4, 'ok'], [9.2, 'ok'], [9.8, 'fail'], [10.6, 'found'], [12.2, 'facepalm'], [13.5, 'fix']],
  draw(lt, t) {
    const min = clockAt(t);
    if (lt < 12) {
      closeup(t, (x, y, w, h) => {
        ide(x, y, 150, h, t, 'auth.js');
        const found = lt > 10.2;
        codeScreen(x + 38, y + 7, 112, h - 7, 0, null, t, { bugHi: found ? (Math.floor(lt * 4) % 2 ? P.red : P.dred) : null });
        // 右侧终端
        const tx = x + 152, tw = w - 152;
        R(tx, y, tw, h, P.night); R(tx, y, tw, 7, P.navy); text('terminal', tx + 2, y + 1, P.light);
        const q = '> why can anyone deploy?';
        text(q.slice(0, Math.floor(clamp(lt - .3, 0, 2) * 14)), tx + 2, y + 10, P.lime);
        if (lt > 2.2) text('ok! splitting x4...', tx + 2, y + 18, P.cyan);
        TESTS.forEach(([name, dur, pass], i) => {
          const ry = y + 30 + i * 13, p = clamp((lt - 5) / dur, 0, 1);
          if (lt < 3.8) return;
          text(name, tx + 12, ry, P.light);
          R(tx + 32, ry, 60, 5, P.ink); R(tx + 32, ry, Math.round(58 * p), 5, p < 1 ? P.gold : pass ? P.lime : P.red);
          if (p >= 1) text(pass ? 'ok' : 'FAIL', tx + 94 - (pass ? 0 : 6), ry, pass ? P.lime : P.red);
        });
        if (lt > 11.2) { text('git blame L3:', tx + 2, y + 86, P.gray); text('you, 11:00 am', tx + 2, y + 93, P.yellow); }
        // AI 助手本体 + 分身
        const bx = x + w - 18, by = y + h - 16;
        const happy = lt > 2.2 && lt < 3.6 || since('bot') < 2;
        bot(bx, by, t, { happy });
        if (lt > 3.6) TESTS.forEach((_, i) => {
          const ry = y + 30 + i * 13;
          let mx = tx + 3, my = ry - 1;
          if (lt < 4.6) { const p = ease((lt - 3.6) / 1); mx = lerp(bx + 1, mx, p); my = lerp(by + 1, my, p) - Math.sin(p * 3.14) * 10; }
          else if (lt > 10) { const p = ease(clamp((lt - 10) / .8, 0, 1)); mx = lerp(mx, x + 150 - 16 - i * 7, p); my = lerp(my, y + 17 - 10, p); }
          bot(mx, my, t, { small: true, ph: i * 1.7, eye: i === 3 && lt > 9.8 ? P.red : P.cyan });
        });
        if (lt > 10.6) { const ax = x + 38 + 11 + 16 * 4 + 1; R(ax, y + 29, 1, 4, P.yellow); px(ax - 1, y + 30, P.yellow); px(ax + 1, y + 30, P.yellow); }
      }, { typing: lt < 2.2, rim: lt > 10.2 ? P.red : P.cyan });
    } else {
      officeBg(min, t);
      const fixed = lt > 13.5;
      deskSet(t, { typing: fixed, screen: (x, y, w, h) => {
        R(x, y, w, h, fixed ? P.dgreen : P.dred); text(fixed ? '===' : '=', x + 3, y + 3, P.white);
        bot(x + w - 11, y + h - 9, t, { happy: true, small: true });
      }});
      guy(140, FLOOR, { pose: fixed ? 'type' : 'facepalmSit', t: lt, glow: fixed ? P.lime : P.red });
      // 小分身在显示器上蹦
      for (let i = 0; i < 4; i++) bot(146 + i * 9, 86 - Math.abs(Math.round(Math.sin(lt * 6 + i) * 3)), t, { small: true, ph: i });
      ambient(min);
    }
  },
  bub(lt) {
    return [say(lt, .6, 2.1, 110, 118, '交给你了。', ''), say(lt, 2.2, 3.6, 250, 147, '收到！分头行动～', 'ai'),
      say(lt, 10.6, 11.9, 250, 147, '找到了：少了一个等号！', 'ai'),
      say(lt, 12.2, 13.5, 140, 104, '……是我自己写的。', ''), say(lt, 13.6, 15.6, 164, 76, '已修复，再跑一遍～', 'ai'),
      say(since('bot') < 1.6 && lt < 12 ? 0 : -1, 0, 1, 250, 147, '嗨，人类！我在呢～', 'ai')];
  },
  hits(lt) { return lt < 12 ? [{ x: 266, y: 116, w: 16, h: 16, id: 'bot' }] : [{ x: 194, y: 108, w: 12, h: 14, id: 'mug' }]; }
});
COFFEE_T[2] = 71;

/* ================= 8. 17:00 CI 变绿，部署 ================= */
const STAGES = [['build', .6, 1.8], ['test', 1.8, 3.4], ['lint', 3.4, 4.4], ['deploy', 4.4, 6.2]];
Object.assign(CH[7], {
  mood: 'deploy', moodAt: lt => lt < 6.2 ? 'ci' : 'deploy',
  sfx: [[1.8, 'ok'], [3.4, 'ok'], [4.4, 'ok'], [6.2, 'deploy']],
  draw(lt, t) {
    const min = clockAt(t);
    if (lt < 6.9) {
      closeup(t, (x, y, w, h) => {
        R(x, y, w, h, P.night); R(x, y, w, 9, P.navy); text('CI / main', x + 4, y + 2, P.white);
        const sx = x + 44, sw = 46;
        text('#241', x + 6, y + 20, P.gray); text('#242', x + 6, y + 44, P.white);
        STAGES.forEach(([n, a, b], i) => {
          const bx = sx + i * (sw + 6);
          R(bx, y + 16, sw, 13, P.dred); text(n, bx + 3, y + 20, P.salmon); text('x', bx + sw - 6, y + 20, P.white);
          const st = lt < a ? 0 : lt < b ? 1 : 2, c = [P.navy, P.gold, P.green][st];
          R(bx, y + 40, sw, 13, c); text(n, bx + 3, y + 44, st ? P.ink : P.gray);
          if (st === 1) { const k = Math.floor(lt * 8) % 4; px(bx + sw - 6 + [0, 1, 1, 0][k], y + 44 + [0, 0, 1, 1][k], P.ink); }
          if (st === 2) { px(bx + sw - 7, y + 46, P.white); px(bx + sw - 6, y + 47, P.white); px(bx + sw - 5, y + 46, P.white); px(bx + sw - 4, y + 45, P.white); }
          if (i < 3) R(bx + sw, y + 46, 6, 1, P.slate);
        });
        if (lt > 6.2) { const f = Math.floor(lt * 6) % 2; R(x + 40, y + 70, 176, 26, f ? P.lime : P.green); textC('DEPLOYED  v2.4.2', x + 128, y + 80, P.ink); }
        else text('running...', x + 44, y + 70, P.gray);
      }, { typing: false, rim: lt > 6.2 ? P.lime : P.cyan });
    } else {
      officeBg(min, t);
      deskSet(t, { screen: (x, y, w, h) => { R(x, y, w, h, P.green); text('OK', x + 13, y + 8, P.white); } });
      const L = lt - 6.9;
      guy(140, FLOOR, { pose: 'cheer', t: L, mouth: 'o' });
      mate('lin', 100, FLOOR, { pose: 'cheer', t: L + .3 });
      mate('zhao', 226, FLOOR, { pose: 'cheer', t: L + .15, dir: -1 });
      mate('wang', 256, FLOOR, { pose: 'wave', t: L, dir: -1, mouth: 'smile' });
      for (let i = 0; i < 30; i++) { const p = fr(L * .5 + hash(i)); px(60 + hash(i * 3) * 220 + Math.sin(p * 9 + i) * 3, 20 + p * 130, [P.yellow, P.cyan, P.salmon, P.lime][i % 4]); }
      ambient(min);
    }
  },
  bub(lt) {
    return [say(lt, 7.1, 9.8, 100, 116, '（小声）耶——', ''), say(lt, 7.5, 9.8, 226, 116, '（小声）稳！', ''), say(lt, 8, 9.8, 140, 100, '（小声）下班！', '')];
  },
  hits() { return []; }
});
