
/* ================= 角色 ================= */
// 主角与同事共用同一套骨架。x = 身体中心列，y = 脚底线（最下一行像素在 y-1）
const SIT = new Set(['sit', 'type', 'drink', 'sleepy', 'eat', 'facepalmSit', 'scratchSit', 'think', 'boot']);
const HERO = { hair: P.ink, top: P.deep, topD: P.night, pants: P.navy, style: 'messy', glasses: true };
function guy(x, y, o) {
  o = Object.assign({}, HERO, o);
  const d = o.dir || 1, t = o.t || 0, pose = o.pose || 'stand';
  const skin = o.skin || P.skin, hair = o.hair, top = o.top, topD = o.topD || P.night, pants = o.pants;
  const sit = SIT.has(pose);
  let bob = 0; const f4 = Math.floor(t * 8) % 4;
  if (pose === 'walk') bob = (f4 & 1) ? -1 : 0;
  if (pose === 'cheer') bob = -Math.round(Math.abs(Math.sin(t * 9)) * 3);
  const Y = y + bob;
  const r = (dx, dy, w, h, c) => R(d > 0 ? x + dx : x - dx - w + 1, Y + dy, w, h, c);
  const T = -15;                         // 躯干顶
  let hx = 0, hy = 0;                    // 头部偏移（低头 / 打瞌睡）
  if (pose === 'sleepy') { hx = 1; hy = 2 + Math.round(Math.sin(t * 2) * .6); }
  if (pose === 'facepalm' || pose === 'facepalmSit') hy = 1;
  if (pose === 'boot') hx = 1;
  const HT = T - 6 + hy;

  // --- 腿 ---
  if (o.bag) r(-6, T + 1, 3, 7, o.bag);  // 背包
  if (sit) {
    r(-3, -8, 8, 2, pants); r(3, -6, 2, 5, pants); r(3, -1, 3, 1, P.ink);
  } else if (pose === 'walk') {
    const swap = f4 === 2, back = swap ? pants : P.night, front = swap ? P.night : pants;
    if (f4 % 2 === 0) {
      r(-2, -7, 2, 3, back); r(-3, -4, 2, 3, back); r(-4, -1, 3, 1, P.ink);
      r(0, -7, 2, 3, front); r(1, -4, 2, 3, front); r(1, -1, 3, 1, P.ink);
    } else { r(-2, -7, 2, 6, P.night); r(-1, -7, 2, 6, pants); r(-1, -1, 3, 1, P.ink); }
  } else {
    r(-2, -7, 2, 6, P.night); r(0, -7, 2, 6, pants); r(-2, -1, 2, 1, P.ink); r(0, -1, 3, 1, P.ink);
  }
  // --- 躯干 ---
  r(-3, T, 7, 8, top); r(-3, T, 1, 8, topD); r(-2, T, 3, 1, topD); // 连帽衫的帽子褶
  if (o.tie) r(1, T + 1, 1, 4, o.tie);
  if (o.badge) px(d > 0 ? x + 2 : x - 2, Y + T + 3, P.white);
  // --- 头 ---
  r(-2 + hx, HT, 6, 6, skin);
  const st = o.style;
  if (st === 'messy') { r(-3 + hx, HT - 1, 6, 2, hair); r(-3 + hx, HT + 1, 2, 3, hair); r(-2 + hx, HT - 2, 1, 1, hair); r(1 + hx, HT - 2, 1, 1, hair); r(3 + hx, HT - 1, 1, 1, hair); }
  else if (st === 'long') { r(-3 + hx, HT - 1, 6, 2, hair); r(-3 + hx, HT + 1, 2, 7, hair); }
  else if (st === 'bun') { r(-3 + hx, HT - 1, 6, 2, hair); r(-3 + hx, HT + 1, 2, 3, hair); r(-5 + hx, HT - 2, 3, 3, hair); }
  else if (st === 'bald') { r(-3 + hx, HT + 2, 2, 2, hair); px(d > 0 ? x + hx : x - hx, Y + HT, P.peach); }
  else if (st === 'cap') { r(-3 + hx, HT - 1, 6, 2, o.cap || P.red); r(3 + hx, HT, 3, 1, o.cap || P.red); r(-3 + hx, HT + 1, 2, 2, hair); }
  else { r(-3 + hx, HT - 1, 6, 2, hair); r(-3 + hx, HT + 1, 2, 2, hair); }
  if (o.beard) r(0 + hx, HT + 4, 4, 2, hair);
  // 屏幕光映在脸上
  if (o.glow) dith(d > 0 ? x + 1 + hx : x - 3 - hx, Y + HT, 3, 6, o.glow, o.glowLvl || 7);
  // 眼睛
  let eye = o.eyes || 'open';
  if (eye === 'open' && fr(t * .31 + (o.seed || 0)) < .05) eye = 'closed';   // 眨眼
  if (['sleepy', 'stretch'].includes(pose)) eye = 'closed';
  const ex = 2 + hx, ey = HT + 2;
  if (o.glasses) { r(ex - 1, ey - 1, 3, 3, o.glow || P.light); r(ex - 1, ey - 1, 3, 1, P.ink); }
  if (eye === 'closed') r(ex - 1, ey + (o.glasses ? 1 : 0), 2, 1, P.dbrown);
  else if (eye === 'wide') { r(ex, ey - 1, 1, 2, P.ink); }
  else { r(ex, ey, 1, 1, P.ink); if (eye === 'tired') r(ex - 1, ey + 2, 2, 1, P.clay); }
  // 嘴
  const talking = o.talk && (Math.floor(t * 7) % 2 === 0);
  if (pose === 'stretch' || o.mouth === 'o' || pose === 'cheer') r(2 + hx, HT + 4, 2, 2, P.wine);
  else if (talking) r(2 + hx, HT + 4, 2, 1, P.wine);
  else if (o.mouth === 'smile') { r(2 + hx, HT + 4, 2, 1, P.dbrown); px(d > 0 ? x + 4 + hx : x - 4 - hx, Y + HT + 3, P.dbrown); }
  else r(3 + hx, HT + 4, 1, 1, P.clay);
  if (o.phones) { r(-2 + hx, HT - 2, 5, 1, P.ink); r(-1 + hx, HT + 1, 2, 3, P.red); }
  if (o.sweat) { r(5 + hx, HT, 1, 2, P.cyan); px(d > 0 ? x + 5 + hx : x - 5 - hx, Y + HT - 1, P.white); }

  // --- 手臂（在头之后画，才能挡住脸） ---
  const k = Math.floor(t * 10) % 2;
  switch (pose) {
    case 'type': case 'boot':
      r(0, T + 1, 2, 3, top); r(1, T + 4, 5, 2, top);
      r(6, T + 4 + k, 2, 1, skin); r(5, T + 5 - k, 1, 1, P.clay); break;
    case 'drink':
      r(0, T + 1, 2, 3, top); r(2, T - 1, 2, 5, top); r(3, T - 2, 2, 2, skin);
      r(4, T - 5, 3, 4, o.mug || P.white); px(d > 0 ? x + 7 : x - 7, Y + T - 4, o.mug || P.white); break;
    case 'hold':
      r(0, T - 6, 2, 7, top); r(0, T - 8, 2, 2, skin); break;
    case 'phone':
      r(0, T + 1, 2, 3, top); r(1, T + 3, 3, 2, top); r(4, T, 2, 4, P.ink); r(4, T + 1, 1, 2, P.cyan); break;
    case 'stretch': case 'cheer':
      r(-3, T - 7, 2, 8, top); r(2, T - 7, 2, 8, top); r(-3, T - 8, 2, 1, skin); r(2, T - 8, 2, 1, skin); break;
    case 'scratch': case 'scratchSit':
      r(1, T - 3, 2, 4, top); r(-1 + k, HT - 2, 3, 2, skin);
      px(d > 0 ? x - 3 : x + 3, Y + HT - 3 - k, P.gray); px(d > 0 ? x + 4 : x - 4, Y + HT - 4 + k, P.gray); break;
    case 'facepalm': case 'facepalmSit':
      r(1, T - 1, 2, 3, top); r(1, HT + 1, 4, 3, skin); break;
    case 'point':
      r(0, T + 1, 2, 2, top); r(1, T + 2, 6, 2, top); r(7, T + 2, 2, 1, skin); break;
    case 'eat': {
      const up = Math.floor(t * 1.6) % 2;
      r(0, T + 1, 2, 3, top);
      if (up) { r(2, T - 1, 2, 5, top); r(3, T - 2, 2, 2, skin); r(5, T - 4, 1, 3, P.sand); r(4, T - 3, 1, 1, P.sand); }
      else { r(1, T + 4, 4, 2, top); r(5, T + 4, 2, 1, skin); r(7, T + 2, 1, 3, P.sand); }
      break; }
    case 'sleepy':
      r(0, T + 1, 2, 3, top); r(1, T + 4, 5, 2, top); r(6, T + 5, 2, 1, skin); break;
    case 'think':
      r(0, T + 1, 2, 3, top); r(2, T - 1, 2, 5, top); r(3, HT + 5, 2, 2, skin); break;
    case 'wave':
      r(2, T - 6, 2, 7, top); r(2 + k, T - 8, 2, 2, skin); break;
    case 'walk': { const sw = f4 === 0 ? 1 : f4 === 2 ? -1 : 0; r(sw, T + 1, 2, 6, top); r(sw, T + 7, 2, 1, skin); break; }
    default:
      r(0, T + 1, 2, 6, top); r(0, T + 7, 2, 1, skin);
  }
}

// 同事们（同一套骨架，换发型/配色）
const MATES = {
  lin:  { hair: P.dbrown, top: P.pink, topD: P.purple, pants: P.navy, style: 'long', glasses: false, seed: .3 },
  zhao: { hair: P.ink, top: P.green, topD: P.dgreen, pants: P.wine, style: 'cap', cap: P.gold, glasses: false, seed: .6 },
  wang: { hair: P.slate, top: P.slate, topD: P.navy, pants: P.ink, style: 'bald', beard: true, glasses: true, skin: P.clay, seed: .8 },
  pm:   { hair: P.wine, top: P.white, topD: P.light, pants: P.navy, style: 'bun', glasses: false, tie: P.red, badge: true, seed: .1 }
};
const mate = (name, x, y, o) => guy(x, y, Object.assign({}, MATES[name], o));

/* ---------- 猫（彩蛋：点它会叫） ---------- */
function cat(x, y, t, o = {}) {
  const c = P.gold, s = P.tan, meow = o.meow || 0;
  if (o.sleep && !meow) {
    // 团成一团
    R(x, y - 5, 10, 5, c); R(x + 1, y - 6, 8, 1, c); R(x + 2, y - 5, 1, 4, s); R(x + 5, y - 5, 1, 4, s);
    R(x + 8, y - 7, 3, 3, c); px(x + 8, y - 8, c); px(x + 10, y - 8, c); R(x + 9, y - 6, 2, 1, P.dbrown);
    R(x - 2, y - 2, 3, 1, c); px(x - 3, y - 3, c);
    const zz = fr(t * .5);
    if (zz < .7) text('z', x + 11 + zz * 6, y - 12 - zz * 8, P.light);
    return;
  }
  const up = meow > 0 ? 1 : 0;
  R(x, y - 6, 9, 5, c); R(x + 2, y - 6, 1, 5, s); R(x + 5, y - 6, 1, 5, s);
  R(x, y - 1, 2, 1, c); R(x + 7, y - 1, 2, 1, c);
  R(x + 7, y - 10 - up, 5, 4, c); px(x + 7, y - 11 - up, c); px(x + 11, y - 11 - up, c);
  px(x + 9, y - 9 - up, P.ink); px(x + 11, y - 9 - up, P.ink);
  if (meow > 0) R(x + 10, y - 7 - up, 2, 1, P.wine);
  const sw = Math.round(Math.sin(t * 3) * 2);
  R(x - 2, y - 6 + sw, 2, 1, c); R(x - 3, y - 8 + sw, 1, 3, c);
}

/* ---------- AI 助手：屏幕角落的小机器人 ---------- */
function bot(x, y, t, o = {}) {
  const b = Math.round(Math.sin(t * 4 + (o.ph || 0)) * 1), s = o.small;
  const w = s ? 6 : 9, h = s ? 5 : 7;
  y += b;
  R(x, y, w, h, o.body || P.light); R(x, y + h - 1, w, 1, P.gray);
  R(x + 1, y + 1, w - 2, h - 3, P.ink);
  const blink = fr(t * .4 + (o.ph || 0)) < .06;
  const ec = o.eye || P.cyan;
  if (!blink) { px(x + 2, y + 2, ec); px(x + w - 3, y + 2, ec); if (!s) { px(x + 2, y + 3, ec); px(x + w - 3, y + 3, ec); } }
  else { px(x + 2, y + 3, ec); px(x + w - 3, y + 3, ec); }
  if (o.happy && !s) { px(x + 3, y + 4, ec); px(x + 4, y + 4, ec); px(x + 5, y + 4, ec); }
  const ax = x + (w >> 1);
  R(ax, y - 2, 1, 2, P.gray); px(ax, y - 3, Math.floor(t * 3) % 2 ? P.hot : P.yellow);
  if (!s) { px(x - 1, y + 3, P.gray); px(x + w, y + 3, P.gray); }
}
