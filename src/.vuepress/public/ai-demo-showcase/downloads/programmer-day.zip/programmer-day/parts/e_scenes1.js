
/* ================= 场景公共 ================= */
let RT = 0;                                   // 真实时间（秒），只给彩蛋动画用
const FX = { meow: -99, refill: -99, extra: 0, snooze: -99, bot: -99, poke: -99 };
const since = k => RT - FX[k];
const FLOOR = 150;
function Zs(x, y, t) { for (let i = 0; i < 3; i++) { const p = fr(t * .45 + i / 3); if (p < .85) text(p < .4 ? 'z' : 'Z', x + p * 9 + i, y - p * 16, P.light); } }
// 台词：在 [a,b) 时间内显示
const say = (lt, a, b, x, y, s, cls) => (lt >= a && lt < b) ? { x, y, s, cls } : null;
function room(min, wall, wallD) {
  R(0, 0, W, H, wall); for (let x = 0; x < W; x += 24) R(x, 10, 1, FLOOR - 10, wallD);
  R(0, FLOOR - 4, W, 4, wallD); R(0, FLOOR, W, H - FLOOR, P.wine); dith(0, FLOOR, W, H - FLOOR, P.dbrown, 6);
  for (let x = 6; x < W; x += 30) R(x, FLOOR + 6, 14, 1, P.dbrown);
}
// 桌上的咖啡：随时间变空，续杯彩蛋会让它重新满上
function mugLevel(t) {
  let lv = 1 - fr(clamp((t - 29.4) / 26, 0, .999));
  if (t > 57.5) lv = 1 - clamp((t - 57.5) / 14, 0, 1);
  if (t > 71) lv = 1 - clamp((t - 71) / 30, 0, .95);
  if (since('refill') < 30) lv = Math.max(lv, 1 - since('refill') / 30);
  return lv;
}
// 近景：屏幕特写 + 前景后脑勺
function closeup(t, drawScreen, o = {}) {
  R(0, 0, W, H, P.ink); dith(0, 10, W, H, P.night, 8);
  R(28, 16, 264, 124, P.navy); R(30, 18, 260, 120, P.ink);
  g.save(); g.beginPath(); g.rect(32, 20, 256, 116); g.clip(); drawScreen(32, 20, 256, 116); g.restore();
  R(150, 140, 20, 8, P.navy); R(130, 148, 60, 3, P.navy);
  // 桌面 + 键盘
  R(0, 150, W, 30, P.dbrown); R(0, 150, W, 2, P.brown);
  R(96, 156, 128, 14, P.slate); R(96, 168, 128, 2, P.navy);
  for (let ky = 0; ky < 3; ky++) for (let kx = 0; kx < 15; kx++) {
    const hit = o.typing && hash(kx * 3 + ky * 17 + Math.floor(t * 14)) > .9;
    R(99 + kx * 8, 158 + ky * 4 - (hit ? 0 : 0), 6, 3, hit ? P.white : P.gray);
  }
  // 后脑勺（带耳机），边缘被屏幕打亮
  const hx = 70, hy = 146 + Math.round(Math.sin(t * 1.3)), rim = o.rim || P.cyan;
  R(hx - 22, hy + 18, 44, 20, P.deep); R(hx - 22, hy + 18, 44, 1, P.night); R(hx - 7, hy + 12, 14, 7, P.clay);
  R(hx - 20, hy - 3, 3, 7, P.clay); R(hx + 18, hy - 3, 3, 7, P.clay);
  circ(hx, hy, 17, rim); circ(hx, hy + 1, 17, P.ink);
  for (const [dx, dy] of [[-8, -19], [-2, -20], [5, -20], [11, -18]]) { R(hx + dx, hy + dy, 2, 2, P.ink); px(hx + dx, hy + dy - 1, rim); }
  if (o.phones) { R(hx - 17, hy - 20, 34, 3, P.navy); R(hx - 20, hy - 6, 6, 12, P.red); R(hx + 15, hy - 6, 6, 12, P.red); }
  // 手（打字）
  if (o.typing) { const k = Math.floor(t * 10) % 2; R(120, 160 + k, 10, 5, P.skin); R(176, 161 - k, 10, 5, P.skin); R(112, 163, 10, 8, P.deep); R(186, 163, 10, 8, P.deep); }
  // 咖啡
  mug(250, 144, mugLevel(t), t, false, P.white);
}

// 卧室墙面：海报 + 书架 + 地毯
function bedroomDecor() {
  R(186, 40, 30, 36, P.sand); R(186, 40, 30, 2, P.clay); R(189, 45, 24, 14, P.ink);
  text('>_', 191, 48, P.lime); text('HELLO', 191, 62, P.dbrown); text('WORLD', 191, 68, P.dbrown);
  R(236, 74, 50, 3, P.brown);
  [[P.red, 9], [P.deep, 11], [P.gold, 8], [P.green, 10], [P.purple, 9], [P.light, 7]].forEach(([c, h], i) => R(238 + i * 5, 74 - h, 4, h, c));
  R(270, 64, 12, 10, P.light); R(272, 66, 8, 6, P.ink); px(274, 68, P.cyan);   // 旧笔记本电脑
  R(36, FLOOR + 4, 100, 6, P.purple); for (let x = 40; x < 132; x += 8) R(x, FLOOR + 6, 4, 2, P.pink);
}

/* ================= 1. 07:00 闹钟 ================= */
Object.assign(CH[0], {
  mood: 'morning',
  clock: lt => lt < 3.2 ? 420 : lt < 6 ? 429 : lt < 8.6 ? 438 : 447 + (lt - 8.6) * 1.2,
  sfx: [[.3, 'alarm'], [3.2, 'alarm'], [6, 'alarm'], [8.6, 'alarmLoud'], [1.8, 'snooze'], [4.6, 'snooze'], [7.4, 'snooze'], [10.2, 'yawn']],
  draw(lt, t) {
    const min = clockAt(t);
    room(min, P.night, P.ink);
    drawWindow(36, 40, 74, 58, min, t, { seed: 11 });
    R(32, 99, 82, 3, P.light);
    sunPatch(40, 70, min);
    bedroomDecor();
    // 床
    R(144, 104, 5, 46, P.dbrown); R(144, 102, 5, 2, P.brown);
    R(148, 128, 122, 6, P.dbrown); R(150, 134, 3, 16, P.dbrown); R(265, 134, 3, 16, P.dbrown);
    R(148, 123, 122, 5, P.light);
    // 床头柜 + 闹钟
    R(116, 124, 26, 26, P.brown); R(116, 124, 26, 2, P.clay); R(119, 132, 20, 1, P.dbrown);
    const ringing = [[.3, 1.8], [3.2, 4.6], [6, 7.4], [8.6, 9.8]].some(([a, b]) => lt >= a && lt < b) || since('snooze') < .6;
    const sh = ringing ? (Math.floor(lt * 20) % 2) : 0;
    R(121 + sh, 113, 16, 11, P.red); R(123 + sh, 115, 12, 7, P.ink);
    text(fmtClock(min).slice(1), 124 + sh, 116, ringing && Math.floor(lt * 4) % 2 ? P.hot : P.lime);
    R(122 + sh, 111, 3, 2, P.red); R(133 + sh, 111, 3, 2, P.red);
    if (ringing) { px(118, 110, P.yellow); px(117, 113, P.yellow); px(140, 110, P.yellow); px(141, 113, P.yellow); }
    const upT = 8.8;
    if (lt < upT) {
      // 躺着：枕头、脑袋、被子
      R(150, 118, 16, 6, P.white); R(150, 123, 16, 1, P.light);
      R(154, 112, 7, 7, P.skin); R(153, 111, 5, 8, P.ink); R(154, 110, 6, 2, P.ink);
      const hitAt = [1.8, 4.6, 7.4].find(h => lt > h - .5 && lt < h + .35);
      if (hitAt != null) {
        const p = clamp((lt - (hitAt - .5)) / .5, 0, 1), ex = lerp(160, 128, p), ey = lerp(120, 111, p);
        line(160, 121, ex, ey, P.deep); line(160, 122, ex, ey + 1, P.deep); R(ex - 1, ey - 1, 3, 2, P.skin);
      }
      R(158, 116, 3, 1, P.dbrown);                               // 闭着的眼
      R(160, 117, 100, 8, P.red); R(160, 117, 100, 1, P.salmon); R(180, 119, 1, 5, P.dred); R(215, 118, 1, 6, P.dred); R(250, 115, 12, 3, P.red);
      if (!ringing) Zs(166, 108, lt);
    } else if (lt < 9.8) {
      R(186, 118, 76, 7, P.red); R(186, 118, 76, 1, P.salmon);
      guy(172, 130, { pose: 'sit', t: lt, eyes: 'wide', sweat: true });
    } else if (lt < 10.9) {
      guy(130, FLOOR, { pose: 'stretch', t: lt });
      R(186, 118, 76, 7, P.red);
    } else {
      R(186, 118, 76, 7, P.red);
      guy(lerp(128, 40, (lt - 10.9) / 1.1), FLOOR, { pose: 'walk', dir: -1, t: lt, eyes: 'tired' });
    }
    // 猫一直在被子上睡觉（点它会叫）
    cat(226, 118, t, { sleep: true, meow: since('meow') < 1.2 ? 1 : 0 });
    ambient(min);
  },
  bub(lt) {
    return [say(lt, 1.9, 3.1, 160, 104, '再睡五分钟……', 'think'), say(lt, 4.7, 5.9, 160, 104, '再五分钟……', 'think'),
      say(lt, 7.5, 8.5, 160, 104, '最后一次……', 'think'), say(lt, 8.8, 10.2, 172, 104, '要迟到了！！', 'shout')];
  },
  hits(lt) { return [{ x: 220, y: 104, w: 24, h: 16, id: 'cat' }, { x: 118, y: 108, w: 22, h: 16, id: 'clock' }]; }
});

/* ================= 2. 08:30 通勤 ================= */
Object.assign(CH[1], {
  mood: 'commute',
  sfx: [[.1, 'train'], [7.4, 'ding']],
  draw(lt, t) {
    const min = clockAt(t), sway = Math.round(Math.sin(lt * 3.1) * .8);
    // 窗外：两层城市剪影视差滚动
    R(0, 0, W, H, P.light);
    for (const wx of [8, 116, 224]) {
      const x = wx, y = 34, w = 88, h = 48;
      g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
      drawSky(x, y, w, h, min);
      skyline(x, y + 14, w, h - 14, lt * 40 + wx, 5, P.slate, false, min);
      skyline(x, y + 24, w, h - 24, lt * 120 + wx * 2, 9, P.navy, false, min);
      const pole = (lt * 260 + wx * 3) % 200; R(x + w - pole, y, 3, h, P.ink);
      drawRain(x, y, w, h, rainAt(min), t);
      g.restore();
      R(x - 3, y - 3, w + 6, 3, P.gray); R(x - 3, y + h, w + 6, 3, P.gray); R(x - 3, y, 3, h, P.gray); R(x + w, y, 3, h, P.gray);
      dith(x, y, w, h, P.white, 2);   // 玻璃反光
    }
    g.save(); g.translate(0, sway);
    R(0, 10, W, 8, P.gray); R(0, 22, W, 2, P.slate);                     // 行李架/扶杆
    for (let i = 0; i < 9; i++) { const hx = 18 + i * 36, sw = Math.round(Math.sin(lt * 3.1 + i * .4) * 2);
      line(hx, 24, hx + sw, 31, P.slate); R(hx - 2 + sw, 31, 5, 5, P.white); R(hx - 1 + sw, 32, 3, 3, P.light); }
    R(108, 24, 2, 126, P.light); R(214, 24, 2, 126, P.light);
    // 座椅 + 睡着的乘客
    R(0, 128, 104, 8, P.blue); R(0, 136, 104, 3, P.deep); R(220, 128, 100, 8, P.blue); R(220, 136, 100, 3, P.deep);
    mate('wang', 30, 136, { pose: 'sleepy', t: lt });
    mate('lin', 70, 136, { pose: 'phone', t: lt, glow: P.cyan, glowLvl: 5 });
    guy(250, 136, { pose: 'sleepy', t: lt + 1, hair: P.gold, top: P.orange, topD: P.rust, style: 'short', glasses: false });
    mate('zhao', 290, 136, { pose: 'sleepy', t: lt + 2, dir: -1 });
    Zs(40, 110, lt); Zs(258, 110, lt + .5);
    R(0, FLOOR, W, H - FLOOR, P.slate); for (let x = 0; x < W; x += 8) R(x, FLOOR + 3, 4, 1, P.navy);
    // 主角：拉着吊环，另一只手刷手机
    guy(160, FLOOR, { pose: lt < 5 ? 'phone' : 'hold', t: lt, glow: lt < 5 ? P.cyan : null, glowLvl: 6, eyes: 'tired', bag: P.green });
    g.restore();
    // 隧道灯闪过
    if (Math.floor(lt * 3) % 5 === 0) dith(0, 10, W, H, P.ink, 2);
  },
  bub(lt) {
    return [say(lt, 1.2, 4.2, 160, 122, '昨晚的 PR 还没人 review……', 'think'),
      say(lt, 7.5, 9.6, 160, 50, '前方到站：软件园', 'shout')];
  },
  hits() { return []; }
});

/* ================= 3. 09:30 到工位 + 站会 ================= */
function officeBg(min, t, o = {}) {
  room(min, min >= 1080 ? P.navy : P.slate, min >= 1080 ? P.night : P.navy);
  drawWindow(226, 26, 78, 50, min, t, { seed: 21, off: 60 });
  sunPatch(222, 84, min);
  R(222, 77, 86, 3, P.light);
  // 看板
  R(40, 26, 92, 50, P.sand); R(40, 26, 92, 2, P.clay);
  text('TODO', 44, 30, P.dbrown); text('DOING', 74, 30, P.dbrown); text('DONE', 108, 30, P.dbrown);
  R(71, 30, 1, 42, P.clay); R(104, 30, 1, 42, P.clay);
  for (let i = 0; i < 4; i++) R(44 + (i % 2) * 12, 38 + (i >> 1) * 9, 10, 7, [P.yellow, P.salmon, P.cyan, P.yellow][i]);
  R(76, 38, 10, 7, P.lime); R(88, 38, 10, 7, P.yellow);
  R(108, 38, 10, 7, P.lime);
  if (o.blocked) { R(76, 50, 24, 9, P.red); text('BLOCK', 78, 52, P.white); }
  plant(12, 150);
}
function deskSet(t, o = {}) {
  desk(112, 122, 100);
  monitor(146, 94, 36, 22, o.screen);
  keyboard(160, 119, t, o.typing);
  if (o.mug !== false) mug(196, 116, mugLevel(t), t, o.steam);
  R(118, 110, 12, 12, P.navy); R(120, 112, 8, 2, P.slate);   // 主机
  chair(140, FLOOR);
}
Object.assign(CH[2], {
  mood: 'office',
  sfx: [[3, 'boot'], [5.6, 'coffee'], [8.6, 'whoosh']],
  draw(lt, t) {
    const min = clockAt(t);
    if (lt < 8.6) {
      officeBg(min, t);
      R(24, 120, 48, 30, P.navy); R(24, 118, 48, 3, P.gray);
      const brewing = (lt > 5.6 && lt < 7.4) || since('refill') < 1.6;
      coffeeMachine(38, 98, t, brewing);
      const booting = lt > 2.8;
      deskSet(t, {
        mug: lt > 7.4, steam: lt > 7.4,
        screen: (x, y, w, h) => {
          if (!booting) return R(x, y, w, h, P.ink);
          if (lt < 4.2) { R(x, y, w, h, P.deep); circ(x + 18, y + 9, 3, P.white); R(x + 8, y + 16, Math.min(20, (lt - 2.8) * 16), 2, P.white); }
          else { R(x, y, w, h, P.night); R(x + 2, y + 2, 14, 8, P.blue); R(x + 18, y + 2, 16, 18, P.navy); for (let i = 0; i < 4; i++) R(x + 20, y + 4 + i * 4, 10 - i * 2, 1, P.light); }
        }
      });
      if (lt > 5.6 && lt < 7.4) mug(46, 113, (lt - 5.6) / 1.8, t, true);
      let x, pose = 'walk', dir = 1;
      if (lt < 2.6) x = lerp(-10, 140, lt / 2.6);
      else if (lt < 4.4) { x = 140; pose = 'boot'; }
      else if (lt < 5.6) { x = lerp(140, 76, (lt - 4.4) / 1.2); dir = -1; }
      else if (lt < 7.4) { x = 76; pose = 'stand'; dir = -1; }
      else { x = 76; pose = 'drink'; dir = 1; }
      guy(x, FLOOR, { pose, dir, t: lt, bag: lt < 2.6 ? P.green : null, glow: pose === 'boot' ? P.cyan : null, eyes: lt < 7.4 ? 'tired' : 'open', mug: P.white });
      if (pose === 'drink') for (let i = 0; i < 3; i++) { const p = fr(lt * .8 + i / 3); px(82 + i, 128 - p * 10, P.light); }
      if (lt < 2.6) R(118, 146, 10, 4, P.green);
      ambient(min);
    } else {
      // 站会：五个人，每个人都说"没有阻塞"，看板上却挂着 BLOCK
      officeBg(min, t, { blocked: true });
      const L = lt - 8.6;
      mate('pm', 64, FLOOR, { t: lt, talk: L < .9 || L > 4.7, dir: 1 });
      mate('lin', 118, FLOOR, { t: lt, talk: L > .9 && L < 1.8, dir: -1 });
      mate('zhao', 150, FLOOR, { t: lt, talk: L > 1.9 && L < 2.8, dir: -1 });
      mate('wang', 182, FLOOR, { t: lt, talk: L > 2.9 && L < 3.8, dir: -1 });
      guy(214, FLOOR, { pose: L > 3.8 && L < 4.8 ? 'stand' : 'drink', t: lt, dir: -1, talk: L > 3.9 && L < 4.8, sweat: L > 3.9 && L < 4.8, mug: P.white });
      ambient(min);
    }
  },
  bub(lt) {
    const L = lt - 8.6;
    return [say(lt, .4, 2.4, 60, 110, '早……', 'think'),
      say(lt, 5.8, 7.4, 76, 110, '续命时间', 'think'),
      say(L, 0, .9, 64, 124, '站会，一人一句', ''),
      say(L, .9, 1.9, 118, 124, '没有阻塞', ''), say(L, 1.9, 2.9, 150, 124, '没有阻塞', ''),
      say(L, 2.9, 3.9, 182, 124, '没有阻塞', ''), say(L, 3.9, 4.8, 214, 124, '没……没有阻塞', ''),
      say(L, 4.8, 5.4, 64, 124, '很好，散会！', 'shout')];
  },
  hits(lt) { return lt < 8.6 ? [{ x: 36, y: 96, w: 18, h: 24, id: 'coffee' }] : []; }
});
COFFEE_T[0] = 29.4;
