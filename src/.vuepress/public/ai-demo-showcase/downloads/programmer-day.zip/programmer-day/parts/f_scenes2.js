
/* ================= 4. 10:30 心流 ================= */
const CODE_CUM = []; { let s = 0; for (const l of CODE) { CODE_CUM.push(s); s += l[0].length + 3; } CODE_CUM.push(s); }
function typedPos(chars) { // 已打出的字符数 → [行, 行内字符]
  const tot = CODE_CUM[CODE.length], loops = Math.floor(chars / tot); let c = chars - loops * tot, i = 0;
  while (i < CODE.length - 1 && CODE_CUM[i + 1] <= c) i++;
  return [loops * CODE.length + i, Math.min(CODE[i][0].length, Math.floor(c - CODE_CUM[i]))];
}
function ide(x, y, w, h, t, file) {
  R(x, y, w, h, P.ink); R(x, y, w, 7, P.night); R(x + 1, y + 1, textW(file) + 4, 6, P.ink); text(file, x + 3, y + 1, P.light);
  R(x, y + 7, 38, h - 7, P.night);
  const files = ['src', ' app.js', ' auth.js', ' ci.yml', 'test', ' auth.t.js'];
  files.forEach((f, i) => text(f, x + 2, y + 10 + i * 7, f.trim() === file ? P.yellow : P.gray));
}
function toast(x, y, s, c) { const w = textW(s) + 6; R(x - w, y, w, 9, c); R(x - w, y + 8, w, 1, P.ink); text(s, x - w + 3, y + 2, P.ink); }
Object.assign(CH[3], {
  mood: 'flow',
  sfx: [],
  draw(lt, t) {
    const [line, ch] = typedPos(lt * 17 + 4);
    closeup(t, (x, y, w, h) => {
      ide(x, y, w, h, t, 'auth.js');
      codeScreen(x + 38, y + 7, w - 38, h - 7, Math.max(0, line - 14), ch, t);
      for (let i = 0; i < 4; i++) if (t >= COMMIT_T[i] && t < COMMIT_T[i] + 1.6) toast(x + w - 3, y + 10, 'commit #' + (i + 1) + ' ok', P.lime);
    }, { typing: true, phones: true, rim: P.cyan });
    // 心流：世界的边缘慢慢暗下去
    const v = Math.round(clamp(lt / 3, 0, 1) * 6);
    dith(0, 10, 28, H, P.ink, v + 4); dith(292, 10, 28, H, P.ink, v + 4); dith(0, 10, W, 8, P.ink, v + 4);
    if (lt > 2 && lt < 10) { const n = Math.floor(lt * 3) % 4; text('~'.repeat(n + 1), 24, 150, P.purple); }
  },
  bub(lt) {
    return [say(lt, 7.6, 9.2, 300, 120, '在忙吗？', ''), say(lt, 9.6, 10.8, 300, 120, '……好的。', '')];
  },
  hits(lt) { return [{ x: 246, y: 138, w: 14, h: 12, id: 'mug' }]; }
});

/* ================= 5. 12:00 午饭 ================= */
Object.assign(CH[4], {
  mood: 'lunch',
  sfx: [[.4, 'slurp'], [3, 'slurp']],
  draw(lt, t) {
    const min = clockAt(t);
    room(min, P.clay, P.brown);
    drawWindow(98, 26, 124, 56, min, t, { seed: 33, off: 200, sky: 18 });
    R(94, 83, 132, 3, P.sand);
    sunPatch(100, 120, min);
    // 冰箱 + 微波炉
    R(14, 70, 30, 80, P.light); R(14, 100, 30, 1, P.gray); R(40, 80, 2, 8, P.gray); R(40, 106, 2, 8, P.gray);
    R(20, 78, 6, 5, P.yellow); R(28, 84, 5, 6, P.salmon);          // 冰箱贴
    R(252, 96, 40, 24, P.navy); R(254, 98, 26, 20, P.ink); text('0:42', 257, 105, P.lime); R(252, 120, 48, 30, P.brown);
    // 桌子与面
    R(110, 126, 100, 3, P.sand); R(112, 129, 3, 21, P.clay); R(205, 129, 3, 21, P.clay);
    for (const [bx, s] of [[128, 0], [182, 1.3]]) {
      R(bx, 120, 12, 6, P.white); R(bx + 1, 126, 10, 1, P.light); R(bx + 1, 120, 10, 2, P.gold);
      for (let i = 0; i < 3; i++) { const p = fr(lt * .6 + i / 3 + s); px(bx + 3 + i * 3 + Math.round(Math.sin(p * 8)), 118 - p * 10, p < .5 ? P.white : P.light); }
    }
    chair(114, FLOOR, P.dbrown); chair(206, FLOOR, P.dbrown);
    guy(116, FLOOR, { pose: 'eat', t: lt, eyes: lt > 5 ? 'open' : 'open' });
    mate('lin', 204, FLOOR, { pose: 'eat', t: lt + .6, dir: -1, talk: lt > 2.4 && lt < 3.6 });
    mate('zhao', 240, FLOOR, { pose: lt < 4.2 ? 'phone' : 'stand', t: lt, dir: -1, talk: (lt > .8 && lt < 2.2) || (lt > 4.2 && lt < 5.4), glow: lt < 4.2 ? P.cyan : null });
    ambient(min);
  },
  bub(lt) {
    return [say(lt, .8, 2.3, 240, 124, '这家外卖又涨价了', ''), say(lt, 2.4, 3.8, 204, 124, '下午还有需求评审……', ''),
      say(lt, 4.2, 5.5, 240, 124, '你怎么不说话？', ''), say(lt, 5.5, 7.6, 116, 124, '（还在想那个缓存）', 'think')];
  },
  hits() { return []; }
});
