
/* ================= 声音：WebAudio 实时合成 8-bit ================= */
const AU = {
  ctx: null, master: null, music: null, sfx: null, muted: true, started: false, nextBeat: 0, step: 0, mood: '',
  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain(); this.master.gain.value = 0; this.master.connect(this.ctx.destination);
    this.music = this.ctx.createGain(); this.music.gain.value = .32; this.music.connect(this.master);
    this.sfx = this.ctx.createGain(); this.sfx.gain.value = .55; this.sfx.connect(this.master);
    // 噪声缓冲（键盘、鼓、雨）
    const n = this.ctx.sampleRate; this.noise = this.ctx.createBuffer(1, n, n);
    const d = this.noise.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  },
  setMuted(m) {
    this.muted = m; if (!this.ctx) return;
    if (!m && this.ctx.state === 'suspended') this.ctx.resume();
    const g_ = this.master.gain, now = this.ctx.currentTime;
    g_.cancelScheduledValues(now); g_.setValueAtTime(g_.value, now); g_.linearRampToValueAtTime(m ? 0 : .8, now + .15);
  },
  tone(f, when, dur, type = 'square', vol = .2, dest = this.music, slide = 0) {
    const c = this.ctx, o = c.createOscillator(), g_ = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, when);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f * slide), when + dur);
    g_.gain.setValueAtTime(0.0001, when); g_.gain.linearRampToValueAtTime(vol, when + .005);
    g_.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    o.connect(g_); g_.connect(dest); o.start(when); o.stop(when + dur + .02);
  },
  hiss(when, dur, vol = .15, hp = 3000, dest = this.sfx) {
    const c = this.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g_ = c.createGain();
    s.buffer = this.noise; f.type = 'highpass'; f.frequency.value = hp;
    g_.gain.setValueAtTime(vol, when); g_.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    s.connect(f); f.connect(g_); g_.connect(dest); s.start(when, Math.random() * .5); s.stop(when + dur + .02);
  },
  // ----- 音效 -----
  play(name) {
    if (!this.ctx || this.muted) return;
    const t = this.ctx.currentTime + .01, T = (f, a, d, ty, v, s) => this.tone(f, t + a, d, ty || 'square', v || .2, this.sfx, s || 0);
    switch (name) {
      case 'alarm': for (let i = 0; i < 6; i++) T(i % 2 ? 1320 : 1760, i * .2, .12, 'square', .13); break;
      case 'alarmLoud': for (let i = 0; i < 8; i++) T(i % 2 ? 1320 : 1760, i * .14, .1, 'square', .18); break;
      case 'alarmSoft': T(880, 0, .2, 'triangle', .1); T(1320, .25, .3, 'triangle', .1); break;
      case 'snooze': this.hiss(t, .06, .3, 800); T(220, 0, .08, 'square', .15, .5); break;
      case 'yawn': T(300, 0, .7, 'triangle', .12, .6); break;
      case 'train': for (let i = 0; i < 6; i++) { this.hiss(t + i * .55, .12, .12, 300); this.hiss(t + i * .55 + .14, .12, .1, 300); } break;
      case 'ding': T(988, 0, .5, 'triangle', .18); T(784, .35, .7, 'triangle', .18); break;
      case 'boot': [523, 659, 784, 1047].forEach((f, i) => T(f, i * .09, .25, 'triangle', .12)); break;
      case 'coffee': for (let i = 0; i < 14; i++) this.hiss(t + i * .1, .08, .12, 1500 + Math.random() * 2000); T(1568, 1.5, .12, 'square', .1); T(2093, 1.62, .2, 'square', .1); break;
      case 'whoosh': this.hiss(t, .35, .18, 1200); break;
      case 'key': this.hiss(t, .03, .22, 2500); T(180 + Math.random() * 60, 0, .025, 'square', .05); break;
      case 'commit': T(784, 0, .07, 'square', .12); T(1175, .07, .12, 'square', .12); break;
      case 'slurp': this.hiss(t, .4, .12, 900); T(400, 0, .3, 'sine', .08, 1.8); break;
      case 'siren': for (let i = 0; i < 3; i++) T(660, i * .4, .38, 'sawtooth', .12, 1.5); break;
      case 'type': for (let i = 0; i < 10; i++) { this.hiss(t + i * .11, .03, .2, 2500); } break;
      case 'bot': T(1200, 0, .06, 'square', .12); T(1600, .07, .06, 'square', .12); T(2000, .14, .1, 'square', .12); break;
      case 'split': for (let i = 0; i < 4; i++) T(600 + i * 300, i * .1, .12, 'square', .12, 1.6); break;
      case 'ok': T(1047, 0, .08, 'square', .12); T(1568, .08, .12, 'square', .12); break;
      case 'fail': T(220, 0, .25, 'square', .15, .7); T(196, .22, .3, 'square', .15, .7); break;
      case 'found': [880, 1175, 1480, 1760].forEach((f, i) => T(f, i * .06, .12, 'square', .12)); break;
      case 'facepalm': this.hiss(t, .08, .35, 400); T(150, 0, .12, 'triangle', .2, .5); break;
      case 'fix': T(659, 0, .1, 'square', .12); T(880, .1, .2, 'square', .12); break;
      case 'deploy': [523, 659, 784, 1047, 784, 1047].forEach((f, i) => T(f, i * .11, i === 5 ? .6 : .14, 'square', .14)); break;
      case 'uhoh': T(494, 0, .2, 'triangle', .18); T(370, .22, .45, 'triangle', .18); break;
      case 'idea': [1047, 1319, 1568, 2093].forEach((f, i) => T(f, i * .07, .3, 'triangle', .13)); break;
      case 'meow': T(700, 0, .35, 'sawtooth', .08, 1.5); T(900, .12, .3, 'triangle', .1, .6); break;
      case 'click': T(1400, 0, .03, 'square', .1); break;
      case 'refill': this.play('coffee'); break;
      case 'poke': T(1800, 0, .05, 'square', .1); T(2400, .06, .08, 'square', .1); break;
    }
  },
  // ----- 背景音乐：按章节换情绪，用音频时钟提前排程 -----
  // 每个情绪：bpm、音阶根音、旋律（音阶级数，-1 休止）、低音、是否打击
  MOODS: {
    morning:  { bpm: 84,  root: 60, sc: [0, 2, 4, 7, 9], mel: [0, -1, 2, -1, 4, 3, 2, -1, 1, -1, 2, -1, 0, -1, -1, -1], bass: [0, 0, 5, 5], drum: 0, lead: 'triangle' },
    commute:  { bpm: 104, root: 57, sc: [0, 2, 3, 5, 7, 8, 10], mel: [0, 2, 4, 2, 5, 4, 2, -1, 0, 2, 4, 6, 5, 4, 2, -1], bass: [0, 0, 3, 4], drum: 1, lead: 'square' },
    office:   { bpm: 112, root: 60, sc: [0, 2, 4, 5, 7, 9, 11], mel: [0, 2, 4, 5, 4, 2, 0, -1, 4, 5, 6, 7, 6, 4, 2, -1], bass: [0, 5, 3, 4], drum: 1, lead: 'square' },
    flow:     { bpm: 128, root: 62, sc: [0, 3, 5, 7, 10], mel: [0, 2, 4, 2, 5, 4, 2, 1, 0, 2, 4, 5, 7, 5, 4, 2], bass: [0, 0, 3, 4], drum: 2, lead: 'square', arp: true },
    lunch:    { bpm: 96,  root: 65, sc: [0, 2, 4, 7, 9], mel: [4, -1, 2, 4, 5, -1, 4, -1, 2, 1, 0, -1, 2, -1, -1, -1], bass: [0, 3, 4, 0], drum: 1, lead: 'triangle' },
    sleepy:   { bpm: 64,  root: 55, sc: [0, 2, 4, 7, 9], mel: [2, -1, -1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1], bass: [0, 0, 0, 0], drum: 0, lead: 'triangle' },
    alert:    { bpm: 150, root: 57, sc: [0, 1, 3, 5, 7, 8, 10], mel: [0, 0, 5, 0, 4, 0, 3, 1, 0, 0, 5, 0, 6, 5, 4, 1], bass: [0, 0, 1, 0], drum: 2, lead: 'sawtooth' },
    ai:       { bpm: 118, root: 64, sc: [0, 2, 4, 6, 7, 9, 11], mel: [0, 4, 7, 4, 2, 6, 9, 6, 0, 4, 7, 11, 9, 7, 6, 4], bass: [0, 3, 5, 4], drum: 1, lead: 'square', arp: true },
    ci:       { bpm: 120, root: 60, sc: [0, 2, 4, 5, 7, 9, 11], mel: [0, -1, 0, -1, 2, -1, 2, -1, 4, -1, 4, -1, 5, 5, 6, 6], bass: [0, 0, 4, 4], drum: 1, lead: 'square' },
    deploy:   { bpm: 132, root: 60, sc: [0, 2, 4, 5, 7, 9, 11], mel: [7, 4, 7, 9, 7, 4, 2, 4, 7, 4, 7, 11, 9, 7, 9, 11], bass: [0, 3, 4, 0], drum: 2, lead: 'square' },
    pm:       { bpm: 90,  root: 58, sc: [0, 2, 3, 5, 7, 8, 10], mel: [4, -1, 3, -1, 2, -1, 1, -1, 0, -1, -1, -1, -1, -1, -1, -1], bass: [0, 0, 5, 5], drum: 0, lead: 'triangle' },
    overtime: { bpm: 176, root: 58, sc: [0, 2, 3, 5, 7, 8, 10], mel: [0, 2, 3, 2, 0, 2, 3, 5, 3, 2, 0, 2, 3, 2, 0, -1], bass: [0, 0, 5, 4], drum: 2, lead: 'square' },
    night:    { bpm: 70,  root: 57, sc: [0, 2, 4, 7, 9], mel: [4, -1, 2, -1, 0, -1, 2, -1, 1, -1, -1, -1, 0, -1, -1, -1], bass: [0, 5, 3, 4], drum: 0, lead: 'triangle' },
    idea:     { bpm: 100, root: 60, sc: [0, 2, 4, 7, 9], mel: [0, 2, 4, 7, 9, 7, 9, 12, -1, -1, -1, -1, -1, -1, -1, -1], bass: [0, 0, 0, 0], drum: 0, lead: 'triangle' }
  },
  note(m, deg) { const sc = m.sc, o = Math.floor(deg / sc.length), i = ((deg % sc.length) + sc.length) % sc.length; return 440 * Math.pow(2, (m.root + sc[i] + 12 * o - 69) / 12); },
  // 每帧调用：rate = 播放倍速（暂停时为 0）
  tick(mood, rate, typing) {
    if (!this.ctx || this.muted || this.ctx.state !== 'running') return;
    const c = this.ctx, now = c.currentTime;
    if (mood !== this.mood) { this.mood = mood; this.step = 0; this.nextBeat = Math.max(this.nextBeat, now + .05); }
    if (!rate) { this.nextBeat = now + .05; return; }
    if (this.nextBeat < now - .2) this.nextBeat = now + .05;
    const m = this.MOODS[mood] || this.MOODS.office;
    const spb = 60 / (m.bpm * (rate > 1 ? 1 + (rate - 1) * .25 : 1)) / 2;   // 八分音符
    while (this.nextBeat < now + .12) {
      const s = this.step, w = this.nextBeat;
      const deg = m.mel[s % 16];
      if (deg >= 0) this.tone(this.note(m, deg + 7), w, spb * .9, m.lead, .07);
      if (m.arp && s % 2) this.tone(this.note(m, m.bass[(s >> 2) % 4] + 14 + (s % 4)), w, spb * .5, 'square', .03);
      if (s % 4 === 0) this.tone(this.note(m, m.bass[(s >> 2) % 4]) / 2, w, spb * 3.5, 'triangle', .16);
      if (m.drum) {
        if (s % 4 === 0) this.tone(120, w, .12, 'sine', .3, this.music, .4);
        if (m.drum > 1 && s % 4 === 2) this.hiss(w, .08, .1, 1500, this.music);
        if (s % 2 === 1) this.hiss(w, .03, .05, 7000, this.music);
      }
      if (typing && (s % 2 === 0 || hash(s) > .5)) this.hiss(w + spb * .1, .03, .12, 2500, this.sfx);  // 有节奏的键盘声
      this.step++; this.nextBeat += spb;
    }
  }
};
