cd "$(dirname "$0")"
cat parts/a_head.html parts/b_core.js parts/c_char.js parts/d_env.js parts/e_scenes1.js parts/f_scenes2.js parts/g_scenes3.js parts/h_scenes4.js parts/i_audio.js parts/j_main.js parts/z_tail.html > index.html
cat parts/b_core.js parts/c_char.js parts/d_env.js parts/e_scenes1.js parts/f_scenes2.js parts/g_scenes3.js parts/h_scenes4.js parts/i_audio.js parts/j_main.js > "$TEMP/chk.js" && node --check "$TEMP/chk.js" && echo BUILD_OK
